;(function(angular, undefined) {
	'use strict';
	
	angular
		.module('app.directives', []);
		
}(angular));