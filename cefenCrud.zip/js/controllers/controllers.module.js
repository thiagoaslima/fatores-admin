;(function(angular, undefined) {
	'use strict';
	
	angular
		.module('app.controllers', []);
	
 })(angular);
