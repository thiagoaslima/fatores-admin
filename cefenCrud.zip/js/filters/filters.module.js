;
(function (angular, undefined) {
	'use strict';

	angular
		.module('app.filters', []);
	
})(window.angular);